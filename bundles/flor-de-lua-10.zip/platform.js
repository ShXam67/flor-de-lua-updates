/* Flor de Lua · ponte entre o app e o aparelho.
   Dentro do Claude o app recebe "window.claude" pronto. Fora dele (APK / instalado),
   esta ponte cria o mesmo contrato: sem nuvem ligada, tudo fica salvo no aparelho. */
(function(){
  if(window.claude)return;
  function compartilhar(cap,filename,text){
    return cap.Filesystem.writeFile({path:filename,data:text,directory:'CACHE',encoding:'utf8'})
      .then(function(r){return cap.Share.share({title:filename,url:r.uri,dialogTitle:'Enviar cópia de segurança'})})
      .then(function(){return {where:null}});
  }
  /* No celular: grava direto em Downloads/FlorDeLua (ou Documentos, se o Android não deixar).
     "share" abre o menu de enviar (WhatsApp, e-mail...). Se tudo falhar, cai no menu de enviar. */
  function baixar(filename,data,share){
    var text=typeof data==='string'?data:JSON.stringify(data);
    var cap=window.Capacitor&&window.Capacitor.Plugins;
    if(cap&&cap.Filesystem&&cap.Share){
      if(share)return compartilhar(cap,filename,text);
      var tenta=function(dir,path,nome){
        return cap.Filesystem.writeFile({path:path,data:text,directory:dir,encoding:'utf8',recursive:true})
          .then(function(){return {where:nome}});
      };
      var pedir=cap.Filesystem.requestPermissions?cap.Filesystem.requestPermissions().catch(function(){}):Promise.resolve();
      return pedir.then(function(){return tenta('EXTERNAL_STORAGE','Download/FlorDeLua/'+filename,'Downloads/FlorDeLua')})
        .catch(function(){return tenta('DOCUMENTS','FlorDeLua/'+filename,'Documentos/FlorDeLua')})
        .catch(function(){return compartilhar(cap,filename,text)});
    }
    var blob=new Blob([text],{type:filename.slice(-4)==='.csv'?'text/csv;charset=utf-8':'application/json'});
    var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=filename;
    document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},1500);
    return Promise.resolve();
  }
  window.claude={use:function(nome){
    if(nome==='downloads')return Promise.resolve({save:function(o){return baixar(o.filename,o.data,o.share)}});
    var C=window.FlorCloud;
    if(C&&C.ready){
      if(nome==='db')return C.db();
      if(nome==='user')return C.user();
    }
    return Promise.resolve(null); // sem nuvem: o app usa só o aparelho
  }};
})();

/* Botão voltar do Android: o app decide (fecha só a tela de cima). Sem nada aberto, minimiza. */
(function(){
  try{
    var cap=window.Capacitor&&window.Capacitor.Plugins,App=cap&&cap.App;
    if(!App||!App.addListener)return;
    App.addListener('backButton',function(){
      try{if(window.flBack&&window.flBack())return}catch(e){}
      try{if(App.minimizeApp)App.minimizeApp();else App.exitApp()}catch(e){}
    });
  }catch(e){}
})();
