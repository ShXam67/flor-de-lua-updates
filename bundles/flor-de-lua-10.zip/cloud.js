/* ============================================================
   Flor de Lua · sincronização com a conta Google (Firebase)
   - Entra com Google; guarda tudo em users/{uid}/... no Firestore.
   - O app continua salvando no aparelho primeiro; a nuvem só acompanha.
   - Se as chaves não foram preenchidas (firebase-config.js), fica desligado.
   Contrato com o app (ver platform.js):
     db()   -> { doc(p), collection(p) } estilo Firestore, já dentro de users/{uid}
     user() -> { can(), id() }  |  null se ninguém entrou
   ============================================================ */
(function(){
  var cfg=window.FLOR_FIREBASE_CONFIG;
  var ok=!!(cfg&&cfg.apiKey&&cfg.apiKey.indexOf('COLE_AQUI')<0&&cfg.projectId&&cfg.projectId.indexOf('COLE_AQUI')<0&&window.firebase&&firebase.initializeApp);
  var C=window.FlorCloud={ready:ok,config:cfg||null,state:{user:null},authReady:Promise.resolve(),
    db:async function(){return null},user:async function(){return null}};
  if(!ok)return;
  var auth,fs,uid=null,resolveAuth;
  try{
    firebase.initializeApp(cfg);
    auth=firebase.auth();fs=firebase.firestore();
    try{fs.enablePersistence({synchronizeTabs:true}).catch(function(){})}catch(e){}
  }catch(e){C.ready=false;return}
  C.authReady=new Promise(function(r){resolveAuth=r;setTimeout(r,6000)});
  auth.onAuthStateChanged(function(u){
    uid=u?u.uid:null;
    C.state.user=u?{uid:u.uid,email:u.email||'',name:u.displayName||''}:null;
    resolveAuth();
  });
  var base=function(p){return 'users/'+uid+'/'+p};
  C.user=async function(){await C.authReady;if(!uid)return null;return {can:async function(){return true},id:async function(){return uid}}};
  C.db=async function(){await C.authReady;if(!uid)return null;
    return {doc:function(p){return fs.doc(base(p))},collection:function(p){return fs.collection(base(p))}}};
  /* Dentro do APK o login é feito pelo próprio Android (plugin FirebaseAuthentication);
     no navegador é o popup do Google. */
  var cap=window.Capacitor,native=!!(cap&&cap.isNativePlatform&&cap.isNativePlatform());
  var nativeAuth=function(){return cap&&cap.Plugins&&cap.Plugins.FirebaseAuthentication};
  C.signIn=async function(){
    if(native){
      var P=nativeAuth();if(!P)throw new Error('plugin de login ausente');
      var r=await P.signInWithGoogle({skipNativeAuth:true});
      var c=r&&r.credential;if(!c||!c.idToken)throw new Error('sem credencial');
      await auth.signInWithCredential(firebase.auth.GoogleAuthProvider.credential(c.idToken,c.accessToken||null));
      location.reload();return;
    }
    var prov=new firebase.auth.GoogleAuthProvider();prov.setCustomParameters({prompt:'select_account'});
    try{await auth.signInWithPopup(prov)}
    catch(e){
      if(e&&(e.code==='auth/popup-blocked'||e.code==='auth/operation-not-supported-in-this-environment')){await auth.signInWithRedirect(prov);return}
      if(e&&(e.code==='auth/popup-closed-by-user'||e.code==='auth/cancelled-popup-request'))return;
      throw e;
    }
    location.reload();
  };
  C.signOut=async function(){
    try{if(native&&nativeAuth())await nativeAuth().signOut()}catch(e){}
    await auth.signOut();location.reload();
  };
  /* cópias de segurança guardadas na conta (guarda as 40 mais novas) */
  C.backup=async function(json,tag,counts){
    if(!uid)return;
    var now=Date.now();
    await fs.doc(base('backups/'+now)).set({at:now,tag:tag||'',json:json,nc:(counts&&counts.nc)||0,nv:(counts&&counts.nv)||0});
    try{
      var q=await fs.collection(base('backups')).orderBy('at','desc').get();
      var extra=q.docs.slice(40);for(var i=0;i<extra.length;i++)await extra[i].ref.delete();
    }catch(e){}
  };
  C.listBackups=async function(){
    if(!uid)return [];
    var q=await fs.collection(base('backups')).orderBy('at','desc').limit(30).get();
    return q.docs.map(function(d){var v=d.data();return {id:d.id,at:v.at,tag:v.tag,json:v.json,nc:v.nc,nv:v.nv}});
  };
})();
