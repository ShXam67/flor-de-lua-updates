/* De onde o app busca atualizações: um repositório PÚBLICO só com o app pronto.
   Nele não ficam dados de clientes. Veja COMO_ATUALIZAR_PELO_APP.md. */
window.FLOR_UPDATE_URL='https://raw.githubusercontent.com/ShXam67/flor-de-lua-updates/main/';
