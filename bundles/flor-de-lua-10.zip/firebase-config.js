/* Sincronização com a nuvem: DESLIGADA de propósito.
   O app guarda tudo só neste aparelho; a cópia de segurança é por arquivo (Ajustes -> Salvar cópia).
   Se um dia quiser ligar, veja FUTURO_SINCRONIZACAO.md. As chaves do projeto "flor-de-lua" estão guardadas ali. */
window.FLOR_FIREBASE_CONFIG=null;
