window.FLOR_BUILD=6;window.FLOR_VERSION='1.6';
