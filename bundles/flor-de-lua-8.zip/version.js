window.FLOR_BUILD=8;window.FLOR_VERSION='1.8';
