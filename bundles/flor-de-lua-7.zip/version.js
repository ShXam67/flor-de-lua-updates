window.FLOR_BUILD=7;window.FLOR_VERSION='1.7';
